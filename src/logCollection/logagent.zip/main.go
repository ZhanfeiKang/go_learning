package main

import (
	"fmt"
	"logagent/kafka"
	"logagent/tailfile"
	"strings"
	"time"

	"github.com/Shopify/sarama"
	"github.com/go-ini/ini"
	"github.com/sirupsen/logrus"
)

// 日志收集的客户端
// 类似的开源项目还有filebeat
// 收集指定目录下的日志文件，发送到kafka中

// 现在的技能包：
// 往kafka发数据
// 使用tail读日志文件

// 整个logagent的配置结构体
type Config struct {
	KafkaConfig `ini:"kafka"`
	Collect     `ini:"collect"`
}

type KafkaConfig struct {
	Address  string `ini:"address"`
	ChanSize int64  `ini:"chan_size"`
}

type Collect struct {
	LogFilePath string `ini:"logfile_path"`
}

// 真正的业务逻辑
func run() (err error) {
	// logfile --> TailObj --> log --> Client --> kafka
	for {
		// 循环读数据
		line, ok := <-tailfile.TailObj.Lines // chan tail.Line
		if !ok {
			logrus.Warn("tail file close reopen,filename:%s\n", tailfile.TailObj.Filename)
			time.Sleep(time.Second) // 读取出错等一秒
			continue
		}
		// 如果是空行就略过
		if len(strings.Trim(line.Text, "\r\n")) == 0 {
			continue
		}
		// 利用 channel 将同步的代码改为异步的
		// 把读出来的一行日志包装成 kafka 里面的 msg 类型，丢到 channel 中
		msg := &sarama.ProducerMessage{}
		msg.Topic = "web_log"
		msg.Value = sarama.StringEncoder(line.Text)
		// 丢到 channel 中
		kafka.ToMsgChan(msg)

	}
}

func main() {
	var configObj = new(Config)
	// 0.读配置文件 `go-ini`
	// cfg, err := ini.Load("./conf/config.ini")
	// if err != nil {
	// 	logrus.Error("load config failed,err:%v", err)
	// 	return
	// }
	// kafkaAddr := cfg.Section("kafka").Key("address").String()
	// fmt.Println(kafkaAddr)
	err := ini.MapTo(configObj, "./conf/config.ini")
	if err != nil {
		logrus.Error("load config failed,err:%v", err)
		return
	}
	fmt.Printf("%#v\n", configObj)
	// 1.初始化连接kafka（做好准备工作）
	err = kafka.Init([]string{configObj.KafkaConfig.Address}, configObj.KafkaConfig.ChanSize)
	if err != nil {
		logrus.Error("init kafka failed,err:%v", err)
		return
	}
	logrus.Info("init kafka success~")
	// 2.根据配置中的日志路径初始化tail，使用tail去收集日志
	err = tailfile.Init(configObj.Collect.LogFilePath)
	if err != nil {
		logrus.Error("init tailfile failed,err:%v", err)
		return
	}
	logrus.Info("init tailfile success~")
	// 3.把日志通过sarama发往kafka
	// TailObj --> log --> Client --> kafka
	err = run()
	if err != nil {
		logrus.Error("run failed, err:%v", err)
		return
	}
}
